CREATE PROCEDURE set_fortestingfirst
    @userName CHAR(30)
  AS
INSERT INTO fortestingfirst VALUES (@userName)
go

