CREATE PROCEDURE setNewTeacher @name NVARCHAR(30), @lastname NVARCHAR(30), @gender NVARCHAR(6) AS INSERT INTO teachers VALUES (@name,@lastname,@gender);
go

