-- if/else
CREATE PROCEDURE statusSalary
  @name NVARCHAR(30)
  AS
  IF (@name = 'Pitt')
      SELECT * FROM vwTeachersSalaryInfo WHERE vwTeachersSalaryInfo.[LastName] = @name
  ELSE
      SELECT * FROM vwTeachersSalaryInfo;
go

