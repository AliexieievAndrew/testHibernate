CREATE PROCEDURE getTeacherByLessonName
  @lessonName NVARCHAR(30)
  AS
  SELECT
    teachers.[Name],
    teachers.[LastName],
    lessons.[NameLesson]
  FROM teachers
    JOIN TeachersInfo ON teachers.id = TeachersInfo.teacher
    JOIN Lessons ON TeachersInfo.lesson = lessons.id
  WHERE [NameLesson] LIKE '%' + @lessonName+ '%';
go

